Name and CLID: August Montalbano agm1564
Assignment: 3
Specify CMPS 415 or CSCE 515: CSCE 515
--
Has anyone helped you with this assignment: No
If yes, identify them and describe the level of help:
N/A

Did you help anyone else with this assignment: No
If yes, identify them and describe the level of help: N/A

Have you incorporated anything from outside sources (web sites, books, previous semesters, etc?): No
If yes, specify the source and level of similarity: N/A

(NOTE: There will be a point reduction if you exceed standards of “Academic Integrity” stated in the syllabus. But, if described accurately above, there will be no further disciplinary action.)

--

Compiler: Visual Studio 2013 Win32
Operating System: Windows 10
List versions used for freeglut, GLEW, and GMTL, if different than requested versions: N/A

List any other nonstandard libraries used: N/A

(NOTE: Your submission must work on a supported configuration.)

--
If compiling requires anything beyond typing "make" or selecting "build", detail it below: N/A


If the program supports any interaction, options, or parameters, give details below:


Clicking and draging the mouse across the viewport will rotate the objects in the scene.

'r': Restarts animation

'z': Raises View Scale
'Z': Reduces View Scale

Quit
'q | Q | Esc'
